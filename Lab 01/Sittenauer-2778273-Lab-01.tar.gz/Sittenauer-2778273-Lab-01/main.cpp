#include "executive.h"

int main(int argc, char* argv[]) {
    executive exec = executive(argv[1]);
    exec.run();
return (5);
}
